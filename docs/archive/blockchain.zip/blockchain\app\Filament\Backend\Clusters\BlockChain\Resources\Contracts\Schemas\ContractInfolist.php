<?php

namespace App\Filament\Backend\Clusters\BlockChain\Resources\Contracts\Schemas;

use App\Models\BlockChain\Contract;
use Filament\Infolists;
use Filament\Schemas;
use Filament\Schemas\Schema;

class ContractInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                // 基本信息
                Schemas\Components\Fieldset::make('基本信息')
                    ->columns(3)
                    ->schema([
                        Infolists\Components\TextEntry::make('tenant.name')
                            ->label(__('backend.tenant'))
                            ->badge(),
                        Infolists\Components\TextEntry::make('name')
                            ->label('合约名称'),
                        Infolists\Components\TextEntry::make('deployer.address')
                            ->label('部署账户')
                            ->copyable()
                            ->copyMessage('已复制部署账户')
                            ->placeholder('-'),
                        Infolists\Components\TextEntry::make('deployer.network.name')
                            ->label('所属网络')
                            ->badge()
                            ->color('success')
                            ->placeholder('-'),
                        Infolists\Components\TextEntry::make('deployer.network.type')
                            ->label('网络类型')
                            ->badge()
                            ->placeholder('-'),
                        Infolists\Components\TextEntry::make('status')
                            ->label(__('backend.status'))
                            ->badge()
                            ->getStateUsing(fn (Contract $record): string => $record->address ? '已部署' : '未部署')
                            ->color(fn (Contract $record): string => $record->address ? 'success' : 'warning'),
                    ]),
                // 链上信息
                Schemas\Components\Fieldset::make('链上信息')
                    ->columns()
                    ->schema([
                        Infolists\Components\TextEntry::make('address')
                            ->label('合约地址')
                            ->copyable()
                            ->copyMessage('已复制合约地址')
                            ->placeholder('-'),
                        Infolists\Components\TextEntry::make('hash')
                            ->label('部署交易哈希')
                            ->copyable()
                            ->copyMessage('已复制交易哈希')
                            ->placeholder('-'),
                        Infolists\Components\TextEntry::make('parameter')
                            ->label('部署参数')
                            ->placeholder('-')
                            ->columnSpanFull(),
                    ]),
                // 代码信息
                Schemas\Components\Fieldset::make('代码信息')
                    ->columnSpanFull()
                    ->schema([
                        Infolists\Components\TextEntry::make('bytecode')
                            ->label('合约字节码')
                            ->html()
                            ->copyable()
                            ->copyMessage('已复制字节码')
                            ->limit(500)
                            ->columnSpanFull(),
                        Infolists\Components\TextEntry::make('abi')
                            ->label('ABI')
                            ->html()
                            ->copyable()
                            ->copyMessage('已复制 ABI')
                            ->limit(500)
                            ->columnSpanFull(),
                        Infolists\Components\TextEntry::make('original')
                            ->label('合约源代码')
                            ->html()
                            ->copyable()
                            ->copyMessage('已复制源代码')
                            ->limit(500)
                            ->columnSpanFull(),
                    ]),
                // 备注信息
                Schemas\Components\Fieldset::make('备注信息')
                    ->columns(1)
                    ->schema([
                        Infolists\Components\TextEntry::make('remark')
                            ->label('备注信息')
                            ->placeholder('-')
                            ->columnSpanFull(),
                    ]),
            ]);
    }
}
