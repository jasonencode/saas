# 区块链模块归档

本目录归档了 SaaS.Foundation 的区块链（BlockChain）模块全部代码。目录结构与项目根一一对应，迁移回去时只需将文件复制/移动到对应路径即可。

## 归档时间

从分支 `feat/coupon-redemption` 归档。

## 归档内容总览

```
docs/archive/blockchain/
├── app/
│   ├── Console/Commands/Test/MultiChainAddressVerify.php   # 多链地址验证命令
│   ├── Contracts/NetworkAdapterInterface.php                # 网络适配器接口
│   ├── Enums/BlockChain/                                    # 枚举（5 个）
│   ├── Filament/
│   │   ├── Actions/BlockChain/                              # Filament Actions（8 个）
│   │   ├── Backend/Clusters/BlockChain/                     # 运营后台集群
│   │   └── Tenant/Clusters/BlockChain/                     # 租户面板集群
│   ├── Http/
│   │   ├── Controllers/Chain/                              # API 控制器（4 个）
│   │   ├── Requests/Chain/StoreCertificateRequest.php
│   │   └── Resources/Chain/                                 # API 资源（4 个）
│   ├── Jobs/BlockChain/DeployContractJob.php
│   ├── Models/BlockChain/                                   # 模型（5 个）
│   ├── Policies/BlockChain/                                # 策略（5 个）
│   ├── Services/BlockChain/CertificateService.php
│   └── Support/
│       ├── BlockChain/                                      # 多链适配层（Rpc/Rlp/Abi/Adapters）
│       └── Certificate/                                     # X.509 证书 PKI 层
├── database/migrations/0006_00_01_000002_create_block_chains_table.php
├── docs/apis/chain.md
├── routes/apis/chain.php
└── tests/
    ├── Feature/
    │   ├── BlockChain/                               # 功能测试（2 个）
    │   └── Chain/                                    # API 端点测试（1 个）
    └── Unit/Enums/BlockChain/                        # 单元测试（1 个）
```

## 迁移回去的步骤

### 1. 移回文件

将本目录下所有文件按原路径移回项目根目录。例如：

```powershell
# 在项目根目录执行
Copy-Item -Recurse -Force docs/archive/blockchain/app/* app/
Copy-Item -Recurse -Force docs/archive/blockchain/database/* database/
Copy-Item -Recurse -Force docs/archive/blockchain/routes/* routes/
Copy-Item -Recurse -Force docs/archive/blockchain/tests/* tests/
Copy-Item -Recurse -Force docs/archive/blockchain/docs/* docs/
```

> 移回后可删除 `docs/archive/blockchain/` 目录。

### 2. 恢复被移除的引用

归档时从以下 **5 个文件** 中移除了对区块链模块的引用，需逐一加回。

#### 2.1 `app/Enums/System/AvailableModule.php`

加回 `BlockChain` 枚举值及三处 `match` 分支：

```php
case Finance = 'finance';

case BlockChain = 'block_chain';   // ← 加回这一行

case User = 'user';
```

```php
// getLabel()
self::Finance => '财务',
self::BlockChain => '区块链',      // ← 加回
self::User => '用户',

// getColor()
self::Finance => 'primary',
self::BlockChain => 'gray',        // ← 加回
self::User => 'primary',

// getClusterClass()
self::Finance => Clusters\Finance\FinanceCluster::class,
self::BlockChain => Clusters\BlockChain\BlockChainCluster::class,  // ← 加回
self::User => Clusters\User\UserCluster::class,
```

#### 2.2 `app/Console/Commands/Maintenance/CleanUnusedFilesCommand.php`

加回 import 和 `$sources` 条目：

```php
use App\Models\BlockChain;   // ← 加回（按字母序放在 Campaign 之前）
```

```php
System\Tenant::class => [
    ['field' => 'avatar', 'type' => 'string'],
],
BlockChain\ContractRepository::class => [   // ← 加回这两个
    ['field' => 'source_path', 'type' => 'string'],
],
Import::class => [
```

#### 2.3 `app/Console/Commands/Seeders/FailedJobSeeder.php`

加回 `JOB_CLASSES` 数组中的条目：

```php
'App\\Jobs\\Content\\GenerateThumbnail',
'App\\Jobs\\Blockchain\\DeployContract',   // ← 加回
'App\\Jobs\\Finance\\GenerateInvoice',
```

#### 2.4 `bootstrap/app.php`

在 `api` 路由数组中加回 `chain.php`：

```php
__DIR__.'/../routes/apis/auth.php',
__DIR__.'/../routes/apis/chain.php',        // ← 加回
__DIR__.'/../routes/apis/content.php',
```

#### 2.5 `config/custom.php`

加回区块链配置块：

```php
/*
|--------------------------------------------------------------------------
| 区块链模块配置
|--------------------------------------------------------------------------
*/
'block_chain' => [
    'public_key' => env('BLOCK_CHAIN_PUBLIC_KEY'),
],
```

### 3. 恢复环境变量

在 `.env` 中加回（如需启用私钥加密存储）：

```env
BLOCK_CHAIN_PUBLIC_KEY=<RSA 公钥>
```

### 4. 刷新自动加载与缓存

```bash
composer dump-autoload
php artisan optimize:clear
```

### 5. 执行数据库迁移

迁移会创建 4 张表：`networks`、`chain_addresses`、`contracts`、`contract_repositories`。

```bash
php artisan migrate
```

> 若数据库中已存在这些表（归档前已迁移过），可跳过此步。
> 若全新数据库，直接执行即可。

### 6. 运行测试

```bash
php artisan test --compact tests/Feature/BlockChain
php artisan test --compact tests/Feature/Chain
php artisan test --compact tests/Unit/Enums/BlockChain
```

## Composer 依赖

归档时从 `composer.json` **移除了**以下依赖，迁回时需重新添加：

| 包 | 用途 |
|----|------|
| `web3p/web3.php` | PHP Web3/Ethereum 客户端（归档时全代码库无实际引用，为遗留依赖） |
| `simplito/elliptic-php` | secp256k1 曲线运算（`Elliptic\EC`） |
| `kornrunner/keccak` | Keccak/SHA3 哈希（`kornrunner\Keccak`） |

加回方式（在 `require` 中按字母序插入）：

```json
"kornrunner/keccak": "^1.1",
"simplito/elliptic-php": "^1.0",
"web3p/web3.php": "^0.3",
```

以下依赖归档时 **仍保留在 `composer.json`** 中（非区块链专属，活跃代码也在使用），无需重新安装：

| 包 | 用途 |
|----|------|
| `tuupola/base58` | Base58 编码，租户标识生成（`TenantForm`、`TenantProfile`）与 Chain33 地址共用 |

另外需要 PHP `gmp` 和 `openssl` 扩展。

## 注意事项

- **租户模块数据**：`Tenant::getModules()` 使用 `AvailableModule::tryFrom()` 并过滤 `null`，因此归档期间即使有租户的 `config.modules` 中仍存有 `block_chain` 值也不会报错，只会被静默忽略。迁回后这些租户会自动恢复区块链模块访问权限。
- **数据库表**：归档后表结构仍保留在数据库中（未执行 drop）。如需彻底清理数据，手动 `DROP TABLE contract_repositories, contracts, chain_addresses, networks`。
- **文档引用**：项目根的 `README.md`、`AGENTS.md`、`docs/` 及 `public/docs/` 中仍有区块链相关文字描述，归档时未改动这些文档，迁回代码后无需修改。
