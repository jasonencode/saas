<?php

namespace App\Console\Commands\Test;

use App\Contracts\NetworkAdapterInterface;
use App\Enums\BlockChain\ChainType;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;

#[Signature('app:test:multichain-address')]
class MultiChainAddressVerify extends Command
{
    public function handle(): void
    {
        $chains = ChainType::cases();

        // 生成一个私钥，在所有链上测试
        $ethAdapter = app(ChainType::Fisco->getAdapter());
        $privateKey = $ethAdapter->generatePrivateKey();

        $this->output->writeln('');
        $this->output->writeln('═══════════════════════════════════════════');
        $this->output->writeln('  同一私钥 · 多链地址');
        $this->output->writeln("  私钥: {$privateKey}");
        $this->output->writeln('═══════════════════════════════════════════');

        $this->output->writeln('');
        $this->output->writeln(str_pad('链名称', 14).str_pad('地址', 46).'私钥验证');
        $this->output->writeln(str_repeat('─', 68));

        foreach ($chains as $chain) {
            /** @var NetworkAdapterInterface $adapter */
            $adapter = app($chain->getAdapter());

            $address = $adapter->getAddressFromPrivateKey($privateKey);

            // 验证：用私钥→公钥→地址 与 直接私钥→地址 一致
            $publicKey = $adapter->getPublicKeyFromPrivateKey($privateKey);
            $addressFromPublicKey = $adapter->getAddressFromPublicKey($publicKey);
            $valid = $address === $addressFromPublicKey ? '✅' : '❌';

            $this->output->writeln(
                str_pad($chain->getLabel(), 14).
                str_pad($address, 46).
                $valid
            );
        }

        $this->output->writeln('');
        $this->output->writeln('═══════════════════════════════════════════');
        $this->output->writeln('  全部完成');
        $this->output->writeln('═══════════════════════════════════════════');
    }

    /**
     * 原 handle 方法：每条链独立生成密钥对，展示完整信息
     */
    public function handleAllChains(): void
    {
        $chains = ChainType::cases();

        foreach ($chains as $chain) {
            $this->output->writeln('');
            $this->output->writeln('═══════════════════════════════════════════');
            $this->output->writeln("  {$chain->getLabel()}");
            $this->output->writeln('═══════════════════════════════════════════');

            /** @var NetworkAdapterInterface $adapter */
            $adapter = app($chain->getAdapter());

            $privateKey = $adapter->generatePrivateKey();
            $publicKey = $adapter->getPublicKeyFromPrivateKey($privateKey);
            $address = $adapter->getAddressFromPrivateKey($privateKey);

            $compressedPublicKey = '';
            if (method_exists($adapter, 'getCompressedPublicKeyFromPrivateKey')) {
                $compressedPublicKey = $adapter->getCompressedPublicKeyFromPrivateKey($privateKey);
            }

            $this->output->writeln("  私钥:          {$privateKey}");
            $this->output->writeln("  公钥(未压缩):  {$publicKey}");
            if ($compressedPublicKey) {
                $this->output->writeln("  公钥(压缩):    {$compressedPublicKey}");
            }
            $this->output->writeln("  地址:          {$address}");

            // 验证一致性
            $addressFromPublicKey = $adapter->getAddressFromPublicKey($publicKey);
            $valid = $address === $addressFromPublicKey ? '✅' : '❌';
            $this->output->writeln("  公私钥一致性:  {$valid}");
        }

        $this->output->writeln('');
        $this->output->writeln('═══════════════════════════════════════════');
        $this->output->writeln('  全部完成');
        $this->output->writeln('═══════════════════════════════════════════');
    }
}
