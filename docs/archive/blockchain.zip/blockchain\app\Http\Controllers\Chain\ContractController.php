<?php

namespace App\Http\Controllers\Chain;

use App\Enums\BlockChain\ContractDeployStatus;
use App\Http\Controllers\Controller;
use App\Http\Resources\Chain\ContractResource;
use App\Http\Responses\ApiResponse;
use App\Models\BlockChain\Contract;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ContractController extends Controller
{
    /**
     * 获取合约列表
     *
     * @param  Request  $request  请求
     *
     * @return JsonResponse 合约列表
     */
    public function index(Request $request): JsonResponse
    {
        $contracts = Contract::ofDeployed()
            ->with(['network'])
            ->when($request->input('name'), function (Builder $builder, string $name) {
                $builder->search('name', $name);
            })
            ->when($request->input('type'), function (Builder $builder, string $type) {
                $builder->where('type', $type);
            })
            ->latest()
            ->paginate(min((int) $request->input('limit', config('custom.pagination.default_per_page')), config('custom.pagination.max_per_page')));

        return ApiResponse::success(ContractResource::collection($contracts));
    }

    /**
     * 获取合约详情
     *
     * @param  Contract  $contract  合约
     *
     * @return JsonResponse 合约详情
     */
    public function show(Contract $contract): JsonResponse
    {
        if ($contract->deploy_status !== ContractDeployStatus::Deployed) {
            return ApiResponse::notFound();
        }

        $contract->load(['network', 'deployer']);

        return ApiResponse::success(ContractResource::make($contract));
    }
}
